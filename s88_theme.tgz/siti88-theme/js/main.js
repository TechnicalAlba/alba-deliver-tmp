/* =============================================
   Siti88 – main.js
   Handles: side-nav (click + swipe), sticky
            header, footer accordion, TOC builder
   ============================================= */

(function () {
  'use strict';

  /* ---- SIDE NAV ---- */
  var menuToggle  = document.getElementById('menuToggle');
  var sideNav     = document.getElementById('sideNav');
  var sideNavClose= document.getElementById('sideNavClose');
  var overlay     = document.getElementById('overlay');

  function openNav() {
    if (sideNav)  sideNav.classList.add('open');
    if (overlay)  overlay.classList.add('open');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeNav() {
    if (sideNav)  sideNav.classList.remove('open');
    if (overlay)  overlay.classList.remove('open');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  /* ---- HOMEPAGE BANNER ---- */
  var banner = document.getElementById('bannerSwiper');
  if (banner) {
    var slides = banner.querySelectorAll('.swiper-slide');
    var dots = banner.querySelector('.swiper-pagination');
    var current = 0;
    var timer = null;

    function showSlide(index) {
      current = (index + slides.length) % slides.length;
      slides.forEach(function (slide, slideIndex) {
        slide.classList.toggle('is-active', slideIndex === current);
      });
      if (dots) dots.querySelectorAll('button').forEach(function (dot, dotIndex) {
        dot.classList.toggle('is-active', dotIndex === current);
        dot.setAttribute('aria-current', dotIndex === current ? 'true' : 'false');
      });
    }

    if (dots) slides.forEach(function (_, index) {
      var dot = document.createElement('button');
      dot.type = 'button';
      dot.setAttribute('aria-label', 'Show banner ' + (index + 1));
      dot.addEventListener('click', function () { showSlide(index); });
      dots.appendChild(dot);
    });
    var next = banner.querySelector('.swiper-button-next');
    var previous = banner.querySelector('.swiper-button-prev');
    if (next) next.addEventListener('click', function () { showSlide(current + 1); });
    if (previous) previous.addEventListener('click', function () { showSlide(current - 1); });
    showSlide(0);
    timer = window.setInterval(function () { showSlide(current + 1); }, 5500);
    banner.addEventListener('mouseenter', function () { window.clearInterval(timer); });
    banner.addEventListener('mouseleave', function () { timer = window.setInterval(function () { showSlide(current + 1); }, 5500); });
  }

  if (menuToggle)  menuToggle.addEventListener('click', openNav);
  if (sideNavClose) sideNavClose.addEventListener('click', closeNav);
  if (overlay)      overlay.addEventListener('click', closeNav);

  /* Auto-close on desktop resize */
  window.addEventListener('resize', function () {
    if (window.innerWidth > 768) closeNav();
  });

  /* Swipe-from-left-edge to open */
  var touchStartX = 0;
  var touchStartY = 0;
  document.addEventListener('touchstart', function (e) {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, { passive: true });

  document.addEventListener('touchend', function (e) {
    var dx = e.changedTouches[0].clientX - touchStartX;
    var dy = Math.abs(e.changedTouches[0].clientY - touchStartY);
    if (touchStartX < 30 && dx > 60 && dy < 60) openNav();
    if (dx < -60 && dy < 60 && sideNav && sideNav.classList.contains('open')) closeNav();
  }, { passive: true });

  /* ---- STICKY HEADER ---- */
  var header = document.querySelector('.header');
  if (header) {
    var headerH = header.offsetHeight;
    window.addEventListener('scroll', function () {
      if (window.scrollY > 100) {
        document.body.classList.add('header-fixed');
        header.style.position = 'fixed';
        header.style.top = '0';
        header.style.left = '0';
        header.style.right = '0';
        header.style.zIndex = '1000';
        document.body.style.paddingTop = headerH + 'px';
      } else {
        document.body.classList.remove('header-fixed');
        header.style.position = '';
        header.style.top = '';
        header.style.left = '';
        header.style.right = '';
        document.body.style.paddingTop = '';
      }
    }, { passive: true });
  }

  /* ---- FOOTER ACCORDION ---- */
  var cardHeaders = document.querySelectorAll('.card-header');
  if (cardHeaders.length) {
    cardHeaders.forEach(function (hdr) {
      hdr.addEventListener('click', function () {
        var content = this.nextElementSibling;
        var isActive = this.classList.contains('active');

        /* close all */
        cardHeaders.forEach(function (h) {
          h.classList.remove('active');
          if (h.nextElementSibling) h.nextElementSibling.style.maxHeight = null;
        });

        /* open clicked one if it was closed */
        if (!isActive && content) {
          this.classList.add('active');
          content.style.maxHeight = content.scrollHeight + 'px';
        }
      });
    });
  }

  /* ---- AUTO TOC (article pages) ---- */
  var articleContent = document.getElementById('articleContent');
  var tocList        = document.getElementById('tocList');
  var tocBox         = document.getElementById('tocBox');

  if (articleContent && tocList) {
    var headings = articleContent.querySelectorAll('h2, h3');

    if (headings.length < 2) {
      if (tocBox) tocBox.style.display = 'none';
    } else {
      headings.forEach(function (h, i) {
        var id = 'toc-' + i;
        h.id = id;
        var li = document.createElement('li');
        if (h.tagName === 'H3') li.className = 'toc-h3';
        var a = document.createElement('a');
        a.href = '#' + id;
        a.textContent = h.textContent;
        li.appendChild(a);
        tocList.appendChild(li);
      });
    }
  }

})();

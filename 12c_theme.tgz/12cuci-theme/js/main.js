/* =============================================
   12Cuci – main.js
   Handles: side-nav (click + swipe), sticky
            header, footer accordion, TOC builder
   ============================================= */

(function () {
  'use strict';

  /* ---- SIDE NAV ---- */
  var menuToggle  = document.getElementById('menuToggle');
  var sideNav     = document.getElementById('sideNav');
  var sideNavClose= document.getElementById('sideNavClose');
  var overlay     = document.getElementById('overlay');

  function openNav() {
    if (sideNav)  sideNav.classList.add('open');
    if (overlay)  overlay.classList.add('open');
    if (sideNav)  sideNav.setAttribute('aria-hidden', 'false');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeNav() {
    if (sideNav)  sideNav.classList.remove('open');
    if (overlay)  overlay.classList.remove('open');
    if (sideNav)  sideNav.setAttribute('aria-hidden', 'true');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  if (menuToggle)  menuToggle.addEventListener('click', openNav);
  if (sideNavClose) sideNavClose.addEventListener('click', closeNav);
  if (overlay)      overlay.addEventListener('click', closeNav);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeNav();
  });

  /* Auto-close on desktop resize */
  window.addEventListener('resize', function () {
    if (window.innerWidth > 768) closeNav();
  });

  /* Swipe-from-left-edge to open */
  var touchStartX = 0;
  var touchStartY = 0;
  document.addEventListener('touchstart', function (e) {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, { passive: true });

  document.addEventListener('touchend', function (e) {
    var dx = e.changedTouches[0].clientX - touchStartX;
    var dy = Math.abs(e.changedTouches[0].clientY - touchStartY);
    if (touchStartX < 30 && dx > 60 && dy < 60) openNav();
    if (dx < -60 && dy < 60 && sideNav && sideNav.classList.contains('open')) closeNav();
  }, { passive: true });

  /* ---- SIDE NAV: Games accordion ---- */
  var gamesToggle = document.querySelector('.side-nav-games-toggle');
  var gamesList   = document.querySelector('.side-nav-games-list');
  if (gamesToggle && gamesList) {
    gamesToggle.addEventListener('click', function () {
      var isOpen = gamesToggle.getAttribute('aria-expanded') === 'true';
      gamesToggle.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
      gamesList.classList.toggle('open', !isOpen);
    });
  }

  /* ---- STICKY HEADER ---- */
  var header = document.querySelector('.header');
  if (header) {
    var headerH = header.offsetHeight;
    window.addEventListener('scroll', function () {
      if (window.scrollY > 100) {
        document.body.classList.add('header-fixed');
        header.style.position = 'fixed';
        header.style.top = '0';
        header.style.left = '0';
        header.style.right = '0';
        header.style.zIndex = '1000';
        document.body.style.paddingTop = headerH + 'px';
      } else {
        document.body.classList.remove('header-fixed');
        header.style.position = '';
        header.style.top = '';
        header.style.left = '';
        header.style.right = '';
        document.body.style.paddingTop = '';
      }
    }, { passive: true });
  }

  /* ---- FOOTER ACCORDION ---- */
  var cardHeaders = document.querySelectorAll('.card-header');
  if (cardHeaders.length) {
    cardHeaders.forEach(function (hdr) {
      hdr.addEventListener('click', function () {
        var content = this.nextElementSibling;
        var isActive = this.classList.contains('active');

        /* close all */
        cardHeaders.forEach(function (h) {
          h.classList.remove('active');
          if (h.nextElementSibling) h.nextElementSibling.style.maxHeight = null;
        });

        /* open clicked one if it was closed */
        if (!isActive && content) {
          this.classList.add('active');
          content.style.maxHeight = content.scrollHeight + 'px';
        }
      });
    });
  }

  /* ---- AUTO TOC (article pages) ---- */
  var articleContent = document.getElementById('articleContent');
  var tocList        = document.getElementById('tocList');
  var tocBox         = document.getElementById('tocBox');

  if (articleContent && tocList) {
    var headings = articleContent.querySelectorAll('h2, h3');

    if (headings.length < 2) {
      if (tocBox) tocBox.style.display = 'none';
    } else {
      headings.forEach(function (h, i) {
        var id = 'toc-' + i;
        h.id = id;
        var li = document.createElement('li');
        if (h.tagName === 'H3') li.className = 'toc-h3';
        var a = document.createElement('a');
        a.href = '#' + id;
        a.textContent = h.textContent;
        li.appendChild(a);
        tocList.appendChild(li);
      });
    }
  }

  /* ---- HOMEPAGE SLIDER ---- */
  var banner = document.getElementById('bannerSwiper');
  if (banner) {
    if (typeof window.Swiper === 'function') {
      new window.Swiper('#bannerSwiper', {
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        pagination: { el: '.swiper-pagination', clickable: true },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }
      });
    } else {
      /* Local no-network fallback preserves four-slide autoplay and controls. */
      banner.classList.add('slider-fallback');
      var slides = banner.querySelectorAll('.swiper-slide');
      var nextButton = banner.querySelector('.swiper-button-next');
      var prevButton = banner.querySelector('.swiper-button-prev');
      var pagination = banner.querySelector('.swiper-pagination');
      var currentSlide = 0;
      var timer = null;

      function showSlide(index) {
        currentSlide = (index + slides.length) % slides.length;
        slides.forEach(function (slide, i) {
          slide.classList.toggle('is-active', i === currentSlide);
          slide.setAttribute('aria-hidden', i === currentSlide ? 'false' : 'true');
        });
        if (pagination) {
          pagination.querySelectorAll('button').forEach(function (dot, i) {
            dot.classList.toggle('is-active', i === currentSlide);
            dot.setAttribute('aria-current', i === currentSlide ? 'true' : 'false');
          });
        }
      }

      if (pagination) {
        pagination.innerHTML = '';
        slides.forEach(function (_, i) {
          var dot = document.createElement('button');
          dot.type = 'button';
          dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
          dot.addEventListener('click', function () { showSlide(i); });
          pagination.appendChild(dot);
        });
      }
      if (nextButton) nextButton.addEventListener('click', function () { showSlide(currentSlide + 1); });
      if (prevButton) prevButton.addEventListener('click', function () { showSlide(currentSlide - 1); });
      showSlide(0);
      if (slides.length > 1) timer = window.setInterval(function () { showSlide(currentSlide + 1); }, 5000);
      banner.addEventListener('mouseenter', function () { if (timer) window.clearInterval(timer); });
      banner.addEventListener('mouseleave', function () { timer = window.setInterval(function () { showSlide(currentSlide + 1); }, 5000); });
    }
  }

})();
